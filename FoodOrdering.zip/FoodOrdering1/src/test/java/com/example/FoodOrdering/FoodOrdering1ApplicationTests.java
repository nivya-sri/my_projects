package com.example.FoodOrdering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrdering1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
