package com.example.FoodOrdering.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.FoodOrdering.model.Dish;
import com.example.FoodOrdering.repository.DishRepository;

import java.util.List;

@RestController
@RequestMapping("/api/dishes")
@CrossOrigin(origins = "http://localhost:3000")
public class DishController {

    @Autowired
    private DishRepository dishRepository;

    // Get all dishes
    @GetMapping
    public ResponseEntity<List<Dish>> getAllDishes() {
        List<Dish> dishes = dishRepository.findAll();
        return ResponseEntity.ok(dishes);
    }

    // Get dish by ID
    @GetMapping("/{id}")
    public ResponseEntity<Dish> getDishById(@PathVariable Long id) {
        return dishRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Create a new dish
    @PostMapping
    public ResponseEntity<Dish> createDish(@RequestBody Dish dish) {
        Dish savedDish = dishRepository.save(dish);
        return new ResponseEntity<>(savedDish, HttpStatus.CREATED);
    }

    // Update a dish
    @PutMapping("/{id}")
    public ResponseEntity<Dish> updateDish(@PathVariable Long id, @RequestBody Dish dishDetails) {
        return dishRepository.findById(id)
                .map(dish -> {
                    dish.setName(dishDetails.getName());
                    dish.setDescription(dishDetails.getDescription());
                    dish.setPrice(dishDetails.getPrice());
                    Dish updatedDish = dishRepository.save(dish);
                    return ResponseEntity.ok(updatedDish);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete a dish
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDish(@PathVariable Long id) {
        return dishRepository.findById(id)
                .map(dish -> {
                    dishRepository.delete(dish);
                    return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}
