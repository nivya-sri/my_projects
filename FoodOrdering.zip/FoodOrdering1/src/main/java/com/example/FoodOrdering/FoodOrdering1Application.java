package com.example.FoodOrdering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodOrdering1Application {

	public static void main(String[] args) {
		SpringApplication.run(FoodOrdering1Application.class, args);
	}

}
